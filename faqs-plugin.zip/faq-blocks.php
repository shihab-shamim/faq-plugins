<?php
/**
 * Plugin Name: FAQ! Plugins
 * Description: Short description of the plugin
 * Version: 1.0.0
 * Author: bPlugins
 * Author URI: https://bplugins.com
 * License: GPLv3
 * License URI: https://www.gnu.org/licenses/gpl-3.0.txt
 * Text Domain: b-blocks
 */

// ABS PATH
if ( !defined( 'ABSPATH' ) ) { exit; }

// Constant
define( 'PREFIX_VERSION', isset( $_SERVER['HTTP_HOST'] ) && 'localhost' === $_SERVER['HTTP_HOST'] ? time() : '1.0.0' );
define( 'PREFIX_DIR_URL', plugin_dir_url( __FILE__ ) );
define( 'PREFIX_DIR_PATH', plugin_dir_path( __FILE__ ) );

if( !class_exists( 'PREFIXPlugin' ) ){
	class PREFIXPlugin{
		function __construct(){
			add_action( 'init', [ $this, 'onInit' ] );
			add_action( 'admin_enqueue_scripts', [ $this, 'myplugin_admin_styles' ] );
		}

		function onInit(){
			register_block_type( __DIR__ . '/build' );
		}

		function myplugin_admin_styles() {
			wp_enqueue_style('myplugin-admin', plugin_dir_url(__FILE__) . 'admin.css', [], PREFIX_VERSION);
		}
	}

	new PREFIXPlugin();
}
